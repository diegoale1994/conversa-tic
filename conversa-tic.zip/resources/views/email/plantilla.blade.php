<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ConversaTIC Fusagasugá</title>
</head>
<body>
	<div class="cuadro">
	
<center>
		<table class="table">
		<tr>
				<td>	

	<h3><strong><center>1er ConversaTIC</center>
	   <p></p> <center>Fusagasugá</center></strong></h3>


	</td>
				<td rowspan="2" >   <img class="img-responsive" src="http://conversatic-fusagasuga.com/images/lo.jpg" alt="slider" width="200" height="160"></td>
		</tr>
		<tr>
				<td>	<h5 ><FONT COLOR="red"> <center>21 de octubre de 2016</center> <p></p><center>5pm 
,cámara de comercio Fusagasugá</center></FONT>
</h5></td>
				
		</tr>		
		</table>




<br>
	<strong>Hola </strong> {{ $data['nombre'] }}<strong>!</strong><br>
	¡Gracias por completar tus datos para <br> participar en el evento y hacer parte de esta  <br> comunidad !

        <br>
        <br>	Te contamos que hemos recibido  <br> satisfactoriamente  tu inscripción, para <br> completarla confirma tu asistencia  <br>haciendo Clic en el enlace.
        <br><br>
		<strong><h3><a class="click" href="http://www.conversatic-fusagasuga.com/user_confirm_event/{{ $data['token'] }}">CLIC AQUI</a></h3></strong>


  
   <h5>Apoyan</h5>
   <a href="http://www.mintic.gov.co/portal/604/w3-channel.html" target="_blank"><img class="img-responsive" src="https://upload.wikimedia.org/wikipedia/commons/c/c2/MinTIC_%28Colombia%29_logo.png" alt="slider" width="200" height="100"></a>
   
   <a href="https://www.redvolucion.gov.co/" target="_blank"><img class="img-responsive" src="http://1.bp.blogspot.com/-NQVE5Raeptg/U-kwXzPxxOI/AAAAAAAAAAw/MQtFn6Yzna4/s320/logo+redvolucion.png" alt="slider" width="200" height="100"></a>
   
   <a href="http://www.theeaglelabs.com/" target="_blank"><img class="img-responsive" src="http://www.theeaglelabs.com/eagleeye/team/tel.png" alt="slider" width="200" height="100"></a><br>
   

   <a href="http://www.ccb.org.co/" target="_blank"><img class="img-responsive" src="http://www.guysandstuff.co/wp-content/uploads/2014/06/C%C3%A1mara-de-Comercio-de-Bogot%C3%A1.png" alt="slider" width="180" height="70"></a>
   
   <a href="http://www.ccb.org.co/Clusters/Cluster-de-Software-y-TI" target="_blank"><img class="img-responsive" src="http://www.ccb.org.co/var/ccb/storage/images/media/ccb/clusters/logos/cluster_software/117966-1-esl-CO/cluster_software.png" width="100" height="90"></a>
   
 <a href="http://centrocomercialmanila.com/" target="_blank"><img class="img-responsive" src="http://centrocomercialmanila.com/wp-content/uploads/manila-web-2015.png" width="100" height="90"></a>
	</p>

</div>
  
</center>
<style type="text/css">
	.cuadro{
		
		margin: 20px;
		padding: 20px;
		font: serif;
		font-size: 25px;
	}
	.color-r{
		color: red;
		margin:0px;
	}
	.click{
	
		text-decoration: none;
		color: #3498db;
	}
	table{
		text-align: center;
	}
</style>
</body>
</html>